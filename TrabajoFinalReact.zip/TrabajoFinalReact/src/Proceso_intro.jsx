import React from 'react';


function proceso_intro() {

    return(
    <div className="container-fluid o-hidden">
      <div className="color-animation-1 mt-4 mb-4">
        <div className="container pt-5 pb-5">
          <div className="row ">
            <div className="col-12 col-lg-8 d-flex justify-content-center">
              <div className="contenedor ">
                <div className="izquierda text-textos">
                  <h2 className="text-titulos">Introduccion</h2>
                  <p>
                    En la actualidad se ha evidenciado una gran falencia, con respecto al código de policía,
                    especialmente enfocado en el maltrato animal, esta problemática ha surgido ya que todos no tienen un
                    conocimiento del código de policía y no tienen presentes las consecuencias que esto puede conllevar
                    faltas graves.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-12 col-lg-4 d-flex justify-content-center">
              <div className="derecha">
              <img src="../public/imagenes_react/Introduccion_Y_proceso_de_elaboracion/introduccion.png" alt=""/>
              </div>
            </div>
          </div>
        </div>
      </div>
     {/*  <!-- FIn de Introduccion -->

      <!-- Inicio del proceso de elaboracion --> */}
      <div className="color-animation mt-4 mb">
        <div className="container pt-5 pb-5">
          <div className="row ">
            <div className="col-12 col-lg-4 d-flex justify-content-center">
              <div className="animacion-1">
              <img src="../public/imagenes_react/Introduccion_Y_proceso_de_elaboracion/proceso_de_elaboracion.jpeg" alt=""/>
            </div>
            </div>
            <div className="col-12 col-lg-8 d-flex justify-content-center">
              <div className="contenedor ">
                <div className="izquierda text-textos">
                  <h2 className="text-titulos">Proceso De elaboracion</h2>
                  <p className="text-justify">Principalmente empezamos con el pitchbok, el cual es un documento de
                    investigacion que consta de varias fases; este proceso es importante para la creacion del manual
                    corporativo el cual es una metodologia de investigacion donde se lleva a cabo un proceso de
                    bocetaje.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div className="row color_separador-1 mt-4">
        <div className="col-12 col-lg-12 d-flex justify-content-center">
          <div className="separador  d-flex justify-content-center align-items-center text-titulos ">

            <h6 className="title_separador text-titulos">Creadores </h6>
          </div>
        </div>
      </div>


    </div>
    )
}
export default proceso_intro