import React from 'react'
function Header () {
    return (
    <div className="container-fluid o-hidden">
      <div className="row px-5">
          <div className="col-12 col-lg-2 p-3 d-felx justify-content-center ">
            <a href="#">
              
            <img src="../public/imagenes_react/Logo/logo.png" className="img-fluid logo" alt=""/>
              </a>
          </div>
          <div className="col-12 col-lg-10 d-flex justify-content-end px-5">
            <div className="d-flex justify-content-center ">
              <ul className="nav nav-pills navbar navbar-expand-lg ">
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                  data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                  aria-label="Toggle navigation">
                  <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                  <div className="navbar-nav ">
                    <li className="item">
                      <a className="nav-link fs-3 " href="#page">Artemisa</a>
                    </li>
                    <li className="item">
                      <a className="nav-link fs-3" href="#Personajes">Memorias</a>
                    </li>
                    <li className="item">
                      <a className="nav-link fs-3" href="#Juega">Diviertete</a>
                    </li>
                  </div>
                </div>
              </ul>
            </div>
          </div>
        </div>
      </div>
    )      
}
export default Header