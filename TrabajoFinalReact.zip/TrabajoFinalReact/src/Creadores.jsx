import React from 'react';

function Creadores(props) {
  return (
    <div className="container-fluid o-hidden">
      <div className="row">
        <div className="col-12 col-lg-6 d-flex justify-content-center pt-4 pb-4">
          <div className="card caja-creador" style={{ width: '18rem' }}>
            <img src="../public/imagenes_react/Creadores/Esneider-.jpg" className="card-img-top imagen-editor" alt="" />
            <div className="card-body">
              <h3>{props.Titulo1}</h3>
              <p className="card-text">
                {props.Texto1} 
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-lg-6 d-flex justify-content-center pt-4 pb-4">
          <div className="card caja-creador" style={{ width: '18rem' }}>
            <img src="../public/imagenes_react/Creadores/Demmis-.jpg" className="card-img-top imagen-editor" alt="" />
            <div className="card-body">
              <h3>{props.Titulo2}</h3>
              <p className="text-justify">{props.Texto2}</p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

export default Creadores;