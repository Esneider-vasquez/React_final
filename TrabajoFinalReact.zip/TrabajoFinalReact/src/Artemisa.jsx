import React from "react";
import Creadores from './Creadores';

function Artemisa(props){
    return(
        <div className="caja">
           <Creadores
        Titulo1="Esneider Vasquez"
        Texto1="Me gusta la programación, me gusta aprender cosas nuevas para auto superarme cada
        dia."
        />

      <Creadores
        Titulo2="Demmis Quiceno "
        Texto2="Mi gran sueño es ser una muy buena fotógrafa, soy una persona muy tierna y alegre."
        />
         
        </div>    
    )
}
export default Artemisa