import React from 'react'
import './App.css'
import Header from './Header'
import Slider from './Slider'
import Proceso_intro from './Proceso_intro'
import Creadores from './Creadores'
import Personajes from './Personajes'
import Artemisa from './artemisa'

import Footer from './Footer'


function App() {
  return (
    <div>
      <Header/>
      <Slider/>
      <Proceso_intro/>
      <Creadores/>
     <Artemisa/>
      <Personajes/>
      <Footer/>
    </div>
  )
}

export default App
