import React from 'react';
function Slider() {
    return(
  <div className="container-fluid o-hidden">
      <div className="row">
      <div className="  col-12 col-lg-12 pb-2 pt-2  ">
        <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="false">
          <div className="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
          </div>
          <div className="carousel-inner">
            <div className="carousel-item active">
            <img src="../public/imagenes_react/Slider/Objetivo_proyecto.png" alt=""/>              
            <div className="color">
                <div className="carousel-caption d-none d-md-block">
                  <h5 className="text-titulos">Objetivo del Proyecto</h5>
                  <p className="text-textos">Enseñar a las personas entre 17 y 19 años la importancia
                    conocer el codigo de policia sobre el maltrato animal mostrando las consecuencias de esta ley</p>
                </div>
              </div>
            </div>
            <div className="carousel-item">
            <img src="../public/imagenes_react/Slider/Des.png" alt=""/>              
              <div className="carousel-caption d-none d-md-block">
                <h5 className="text-titulos">Descripcion del proyecto</h5>
                <p className="text-textos" >Consiste en un juego web llamado ARTEMISA sobre el código
                  de policía, enfocándonos en el maltrato animal, este juego tendrá diferentes niveles y Cada nivel
                  tendrá un enfoque de aprendizaje diferente.</p>
              </div>
            </div>
            
          </div>
          <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>

    <div className="row color_separador-1">
        <div className="col-12 col-lg-12 d-flex justify-content-center">
          <div className="separador  d-flex justify-content-center align-items-center text-titulos ">
            <h6 className="title_separador text-titulos">Proceso e introduccion </h6>
          </div>
        </div>
      </div>
      </div>
    )
    
}
export default Slider