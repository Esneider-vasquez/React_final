import React from 'react'
function Personajes () {
   
    return(
        <div>
        <div className="accordion pt-4 m-5 d-flex justify-content-center" id="accordionExample">
            <div className="col-12 col-lg-6  ">
            <h2 className="accordion-header" id="headingOne">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Gaspar </button>
            </h2>
            <div id="collapseOne" className="accordion-collapse collapse show pt-2 color-animation  margen" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                <div className="d-flex justify-content-center aliguin-items-center" >
    
                <img src="../public/imagenes_react/Personajes_principales/gaspar_modificado.png"  className="Gaspar" alt=""/>
                </div>
                <div className="accordion-body">
                <strong>Es un perro fantasma</strong> Es un perro amigo de apolo, es un perro que ha sufrido mucho maltrato animal y al ver sus amigos apolo muerto le causa un sentimiento de tristeza y lo largo de la historia Gaspar sufre de muchas cosas, no es un perro grosero ni agesivo.
                </div>
            </div>
            </div>
        </div>

            <div className="accordion pt-4 m-5 d-flex justify-content-center" id="accordionExample">
                <div className="col-12 col-lg-6">
                    <div className="accordion-item">
                        <h2 className="accordion-header d-flex justify-content-center" id="headingTwo"></h2>
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Apolo
                            </button>
                        
                        <div id="collapseTwo" className="accordion-collapse collapse  margen color-animation" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div className="d-flex justify-content-center aliguin-items-center" >
            
                        <img src="../public/imagenes_react/Personajes_principales/Perro-fantasma.png" className="Gaspar" alt=""/>                    </div>
                        <div className="accordion-body">
                            <strong>Murio por maltrato animal</strong> Es un perro fantasma , el cual sufrió de maltrato animal por su antiguo por su dueño quien termino por causarle la muerte, pero este queda en el plano terrenal ya que tiene una misión que cumplir, antes de poder descansar en paz.
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
      
    )
}

export default Personajes