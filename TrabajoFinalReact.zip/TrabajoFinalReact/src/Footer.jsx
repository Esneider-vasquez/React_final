import React from 'react';
function Footer() {
    return (
        <div className="row color_separador">
                    
                <div className="col-12 col-lg-2 px-5 pt-2 ">
                <img src="../public/imagenes_react/Logo/logo.png" className="img-fluid logo" alt=""/>
                </div>
                <div className="mt-3 col-12 col-lg-8 pt-5">
                  <div className=" text-center">
                    <small className="text-textos">&copy; ARTEMISA. Todos los derechos reservados.</small>
                  </div>
                </div>
                <div className="col-12 col-lg-2  pt-3 ">
                <img src="../public/imagenes_react/redes/Icono facebook.png"  className="img-fluid mr-3 m-2 alt="/>
                <img src="../public/imagenes_react/redes/Icono instagram.png"  className="img-fluid m-2" alt=""/>
                </div>
        
    </div>
        )

}

export default Footer